export class Customer{
    customerName: string;
    customerEmail: string;
}